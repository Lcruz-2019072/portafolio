import { Auth } from "./Pages/Auth/Auth.jsx";
import { Dashboard } from "./Pages/Dashboard/Dashboard.jsx";

export const routes = [
    {path: '/auth', element: <Auth/>},
    {path: '/*', element: <Dashboard/>}
]
